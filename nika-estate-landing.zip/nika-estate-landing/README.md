# Nika Estate — Emaar landing page

Static single-file landing page (`index.html`). No build step.

## Publish on GitHub Pages
1. Create a new repository and push these files to the `main` branch.
2. Settings → Pages → Source: **Deploy from a branch** → `main` / `/ (root)` → Save.
3. The site goes live at `https://<username>.github.io/<repo>/` in 1–2 minutes.

## Before going live
Set the real WhatsApp number in `index.html` (`CONFIG.WHATSAPP_NUMBER`, digits only, country code first). It is currently the placeholder `971500000000`.
